# Reqbox — Browser-Based API Testing Tool

A full-stack student project demo matching the submitted Reqbox project report: Next.js/React frontend, Express/Node.js backend proxy, Axios HTTP client, and optional MongoDB Atlas persistence with Mongoose.

## Features
- GET, POST, PUT, PATCH and DELETE requests
- Editable query parameters and headers
- JSON/raw request body
- Bearer Token, Basic Auth and API Key authentication
- Environment variables using `{{variable}}`
- Save requests into collections
- Request history
- JSON collection/environment export and import
- Response status, duration, size and formatted body
- Backend proxy to avoid browser-side CORS restrictions
- Responsive desktop/mobile layout

## Requirements
- Node.js 18 or later and npm
- Internet connection for calling public APIs
- Optional MongoDB Atlas connection string for persistent storage

## Run locally
Open a terminal in the project root:

```bash
npm run install:all
```

Copy `server/.env.example` to `server/.env`. For a quick demo, leave `MONGODB_URI` empty; collections, environments and history will be held in memory and reset when the server restarts. For persistent storage, add your MongoDB Atlas connection string to `server/.env`.

Copy `client/.env.local.example` to `client/.env.local`.

Start both applications:

```bash
npm run dev
```

Open **http://localhost:3000**. Backend health check: **http://localhost:5000/**.

## Suggested external demo
1. Open Reqbox and use the sample GET endpoint `https://jsonplaceholder.typicode.com/posts/1`.
2. Show status code, response time, response size and JSON response body.
3. Change method to POST and use `https://jsonplaceholder.typicode.com/posts` with JSON body:

```json
{"title":"Reqbox demo","body":"Testing API from Reqbox","userId":1}
```

4. Add a header or query parameter and send again.
5. Create an environment and use `{{baseUrl}}` in a URL.
6. Save the request to a collection, reopen it from the sidebar, and show history.
7. Export JSON and demonstrate import.

## Deployment notes
- Deploy the `server` folder as a Node web service (Render or equivalent). Set `CLIENT_URL` to the deployed frontend origin and `MONGODB_URI` to your Atlas connection string.
- Deploy the `client` folder as a Next.js app (Vercel or equivalent). Set `NEXT_PUBLIC_API_URL` to the deployed backend origin.
- Do not commit `.env` files or real API keys. Use the hosting provider's environment-variable settings.
- Free hosting services may sleep or have cold starts. Test the deployed app before the external examination.

## Important implementation note
When `MONGODB_URI` is not configured, the backend intentionally uses in-memory demo storage. This makes the app easy to run for a classroom demonstration, but saved collections/environments/history are not retained after a backend restart. Configure MongoDB Atlas for persistence.

## Project identity
**Reqbox: A Browser-Based API Testing Tool**  
Student: Parth Santaji Deshmukh · Roll No. 65  
TYBSc Computer Science · Academic Year 2026–27

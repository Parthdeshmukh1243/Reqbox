import './globals.css';
export const metadata={title:'Reqbox — API Workspace',description:'A lightweight browser-based API testing tool'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}

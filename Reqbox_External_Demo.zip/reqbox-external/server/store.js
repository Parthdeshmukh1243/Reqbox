// In-memory fallback keeps the project demonstrable without cloud credentials.
const store = { collections: [], environments: [], history: [] };
module.exports = store;

const router=require('express').Router();const mongoose=require('mongoose');const History=require('../models/History');const store=require('../store');
router.get('/',async(_req,res)=>res.json(mongoose.connection.readyState===1?await History.find().sort({createdAt:-1}).limit(100).lean():store.history.slice(0,100)));
router.delete('/',async(_req,res)=>{if(mongoose.connection.readyState===1)await History.deleteMany({});else store.history=[];res.json({ok:true});});module.exports=router;

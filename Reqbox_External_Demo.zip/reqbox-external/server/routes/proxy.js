const router = require('express').Router();
const axios = require('axios');
const mongoose = require('mongoose');
const History = require('../models/History');
const store = require('../store');
const PRIVATE = /^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.0\.0\.0|\[?::1)/i;
router.post('/', async (req,res) => {
  const {method='GET',url,headers={},params={},body} = req.body || {};
  let parsed;
  try { parsed = new URL(url); } catch { return res.status(400).json({message:'Enter a valid absolute URL.'}); }
  if (!['http:','https:'].includes(parsed.protocol)) return res.status(400).json({message:'Only HTTP and HTTPS URLs are supported.'});
  if (process.env.ALLOW_PRIVATE !== 'true' && PRIVATE.test(parsed.hostname)) return res.status(403).json({message:'Private/local network addresses are blocked by default.'});
  const started = Date.now();
  try {
    const response = await axios({method,url,headers,params,data:body,timeout:30000,validateStatus:()=>true,responseType:'text',transformResponse:[v=>v]});
    const raw = response.data || ''; const durationMs = Date.now()-started; const sizeBytes = Buffer.byteLength(raw,'utf8');
    const record = {method,url,headers,params,body,status:response.status,durationMs,sizeBytes,createdAt:new Date()};
    if (mongoose.connection.readyState===1) await History.create(record); else store.history.unshift({...record,_id:Date.now().toString()});
    res.json({status:response.status,statusText:response.statusText,headers:response.headers,body:raw,durationMs,sizeBytes});
  } catch(e) { res.status(502).json({error:e.code||'REQUEST_FAILED',message:e.message}); }
});
module.exports = router;

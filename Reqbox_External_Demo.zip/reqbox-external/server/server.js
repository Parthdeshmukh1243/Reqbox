require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const app = express();
app.use(cors({ origin: process.env.CLIENT_URL ? process.env.CLIENT_URL.split(',') : '*' }));
app.use(express.json({ limit: '5mb' }));
app.get('/', (_req, res) => res.json({ app: 'reqbox', status: 'ok', message: 'Reqbox API server is running' }));
app.use('/api/proxy', require('./routes/proxy'));
app.use('/api/collections', require('./routes/collections'));
app.use('/api/environments', require('./routes/environments'));
app.use('/api/history', require('./routes/history'));
app.use('/api/data', require('./routes/transfer'));
const port = process.env.PORT || 5000;
async function start(){
  if (process.env.MONGODB_URI) {
    try { await mongoose.connect(process.env.MONGODB_URI); console.log('MongoDB connected'); }
    catch(e){ console.error('MongoDB connection failed:', e.message); process.exit(1); }
  } else console.log('MONGODB_URI not set: using in-memory demo storage for saved data.');
  app.listen(port, () => console.log(`Reqbox API running on http://localhost:${port}`));
}
start();

const mongoose = require('mongoose');
module.exports = mongoose.models.History || mongoose.model('History', new mongoose.Schema({method:String,url:String,headers:Object,params:Object,body:mongoose.Schema.Types.Mixed,status:Number,durationMs:Number,sizeBytes:Number},{timestamps:true}));

const mongoose = require('mongoose');
module.exports = mongoose.models.Environment || mongoose.model('Environment', new mongoose.Schema({name:{type:String,required:true},variables:Array},{timestamps:true}));

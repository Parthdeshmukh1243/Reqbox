const mongoose = require('mongoose');
module.exports = mongoose.models.SavedRequest || mongoose.model('SavedRequest', new mongoose.Schema({collectionId:{type:String,required:true},name:String,method:String,url:String,headers:Array,params:Array,body:Object,auth:Object},{timestamps:true}));

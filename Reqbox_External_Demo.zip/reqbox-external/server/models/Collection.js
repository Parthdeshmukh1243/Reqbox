const mongoose = require('mongoose');
module.exports = mongoose.models.Collection || mongoose.model('Collection', new mongoose.Schema({name:{type:String,required:true},description:String},{timestamps:true}));
